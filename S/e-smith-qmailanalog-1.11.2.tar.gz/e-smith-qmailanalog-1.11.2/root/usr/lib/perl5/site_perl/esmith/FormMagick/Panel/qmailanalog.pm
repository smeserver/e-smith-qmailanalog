#!/usr/bin/perl -wT
#
# Copyright (C) 2002 Mitel Networks Corporation
#
# Technical support for this program is available from e-smith, inc.
# Please call us at (613) 236-0743 or visit our web site www.e-smith.net
# for details.
#
# $Id: qmailanalog.pm,v 1.5 2003/01/16 20:19:23 markk Exp $
#
#----------------------------------------------------------------------
 
package esmith::FormMagick::Panel::qmailanalog;
 
use strict;
use esmith::FormMagick;
use Exporter;
our @ISA = qw(esmith::FormMagick Exporter);
our @EXPORT = qw(generateReport);
our @VERSION = sprintf '%d.%03d', q$Revision: 1.5 $ =~ /: (\d+).(\d+)/;
 
=pod
 
=head1 NAME
 
esmith::FormMagick::Panel::qmailanalog - useful panel functions
 
=head1 SYNOPSIS
 
	use esmith::FormMagick::Panel::qmailanalog;
	my $panel = esmith::FormMagick::Panel::qmailanalog->new();
	$panel->display();
 
=head1 DESCRIPTION

=head2 new ();
 
Exactly as for esmith::FormMagick
 
=begin testing
 
use_ok 'esmith::FormMagick::Panel::qmailanalog';
$FM = esmith::FormMagick::Panel::qmailanalog->new();
isa_ok($FM, 'esmith::FormMagick::Panel::qmailanalog');
$FM->{cgi} = CGI->new;

=end testing

=cut
 
sub new
{
	shift;
	my $self = esmith::FormMagick->new();
	$self->{calling_package} = (caller)[0];
	bless $self;
	return $self;
}


=pod

=head2 generateReport

Generate and display the requested report.

=begin testing

$FM->{cgi}->param(-name=>'report_type', -value=>'zoverall');
$FM->generateReport();
like($_STDOUT_, qr/REPORT_GENERATED/, 'generateReport');

=end testing

=cut

sub generateReport
{
	my $self = shift;
	my $q = $self->{cgi};

	#------------------------------------------------------------
	# Verify the arguments and untaint the variables (see Camel
	# book, "Detecting and laundering tainted data", pg. 358)
	#------------------------------------------------------------

	my $report_type = $q->param ('report_type');
	if ($report_type =~ /^(\S+)$/)
	{
		$report_type = $1;
	}
	elsif ($report_type =~ /^\s*$/)
	{
		$report_type = "zoverall";
	}
	else
	{
		print $q->p($q->b($self->localise('INVALID_REPORT_TYPE').
			$report_type));
		return '';
	}

	#------------------------------------------------------------
	# Looks good; go ahead and generate the report.
	#------------------------------------------------------------

#	$| = 1;

	my $now_string = $self->gen_locale_date_string();
	print $q->h3($self->localise('REPORT_GENERATED'), $now_string);

	if ($report_type =~ /^qmail-q/)
	{
		open(QMAILQUEUEREPORT, "/var/qmail/bin/$report_type |");

		print "<pre>\n";

		while (<QMAILQUEUEREPORT>)
		{
			print;
		}

		close QMAILQUEUEREPORT;
		print "</pre>\n";

		print $q->h3($self->localise('END_OF_REPORT'));
		return '';
	}

	chdir "/var/log/qmail";

	open(QMAILANALOG,
	"/bin/cat \@* current 2>/dev/null"
	    . "| /usr/local/bin/tai64nunix"
	    . "| /usr/local/qmailanalog/bin/matchup 5>/dev/null"
	    . "| /usr/local/qmailanalog/bin/$report_type |"
	);

	print "<pre>\n";

	while (<QMAILANALOG>)
	{
		# Cook any special HTML characters

		s/\&/\&amp;/g;
		s/\"/\&quot;/g;
		s/\>/\&gt;/g;
		s/\</\&lt;/g;

		print;
	}

	print "</pre>\n";

	close QMAILANALOG;

	print $q->h3($self->localise('END_OF_REPORT'));
	return '';
}


1;

